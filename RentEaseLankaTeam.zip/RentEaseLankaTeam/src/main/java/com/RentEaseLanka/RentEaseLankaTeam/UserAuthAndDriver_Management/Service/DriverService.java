package com.RentEaseLanka.RentEaseLankaTeam.UserAuthAndDriver_Management.Service;

import com.RentEaseLanka.RentEaseLankaTeam.UserAuthAndDriver_Management.Model.*;
import com.RentEaseLanka.RentEaseLankaTeam.UserAuthAndDriver_Management.Repository.DriverRepository;
import com.RentEaseLanka.RentEaseLankaTeam.UserAuthAndDriver_Management.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service class handling core business logic for Driver Management,
 * onboarding, availability tracking, booking assignments, and trip execution.
 */
@Service
public class DriverService {

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private UserRepository userRepository;

    /**
     * Creates an onboarding DriverProfile record linked to a User account with ROLE_DRIVER.
     */
    public DriverProfile createDriverProfile(DriverRegistrationDTO dto) {
        User user = userRepository.findById(dto.getUserId())
                .orElseThrow(() -> new RuntimeException("User account not found with ID: " + dto.getUserId()));

        if (user.getRole() != Role.ROLE_DRIVER) {
            throw new RuntimeException("User account is not assigned the ROLE_DRIVER role.");
        }

        DriverProfile profile = new DriverProfile();
        profile.setUser(user);
        profile.setLicenseNumber(dto.getLicenseNumber());
        profile.setNicNumber(dto.getNicNumber());
        profile.setAvailabilityStatus(AvailabilityStatus.AVAILABLE);

        return driverRepository.save(profile);
    }

    /**
     * Retrieves all active driver profiles currently marked with AVAILABLE status.
     */
    public List<DriverProfile> getAvailableDrivers() {
        return driverRepository.findByAvailabilityStatus(AvailabilityStatus.AVAILABLE);
    }

    /**
     * Assigns an available driver to a specific reservation booking.
     * Transitions driver availability status to ON_TRIP.
     */
    public DriverProfile assignDriverToBooking(Long driverId, Long bookingId) {
        DriverProfile profile = driverRepository.findById(driverId)
                .orElseThrow(() -> new RuntimeException("Driver profile not found with ID: " + driverId));

        if (profile.getAvailabilityStatus() != AvailabilityStatus.AVAILABLE) {
            throw new RuntimeException("Selected driver is not available for assignment.");
        }

        profile.setAvailabilityStatus(AvailabilityStatus.ON_TRIP);
        return driverRepository.save(profile);
    }

    /**
     * Updates a driver's availability state (e.g., AVAILABLE, ON_TRIP, OFF_DUTY, SUSPENDED).
     */
    public DriverProfile updateDriverStatus(Long driverId, AvailabilityStatus status) {
        DriverProfile profile = driverRepository.findById(driverId)
                .orElseThrow(() -> new RuntimeException("Driver profile not found with ID: " + driverId));

        profile.setAvailabilityStatus(status);
        return driverRepository.save(profile);
    }

    /**
     * Driver Duty Portal: Updates assigned trip progress (e.g., STARTED -> COMPLETED).
     * Automatically resets driver availabilityStatus to AVAILABLE when the trip is marked COMPLETED.
     */
    public DriverProfile updateTripStatus(Long driverId, String newStatus) {
        DriverProfile driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new RuntimeException("Driver profile not found with ID: " + driverId));

        if ("COMPLETED".equalsIgnoreCase(newStatus)) {
            driver.setAvailabilityStatus(AvailabilityStatus.AVAILABLE);
        } else if ("STARTED".equalsIgnoreCase(newStatus)) {
            driver.setAvailabilityStatus(AvailabilityStatus.ON_TRIP);
        }

        return driverRepository.save(driver);
    }
}