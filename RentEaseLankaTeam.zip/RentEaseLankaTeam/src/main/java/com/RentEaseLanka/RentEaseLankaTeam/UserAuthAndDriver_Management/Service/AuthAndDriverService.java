package com.RentEaseLanka.RentEaseLankaTeam.UserAuthAndDriver_Management.Service;

import com.RentEaseLanka.RentEaseLankaTeam.UserAuthAndDriver_Management.Model.Role;
import com.RentEaseLanka.RentEaseLankaTeam.UserAuthAndDriver_Management.Model.*;
import com.RentEaseLanka.RentEaseLankaTeam.UserAuthAndDriver_Management.Repository.UserRepository;
import com.RentEaseLanka.RentEaseLankaTeam.UserAuthAndDriver_Management.Security.JwtProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * Service class handling core business logic for Authentication, User Profile Management,
 * and Staff Physical KYC Verification.
 */
@Service
public class AuthAndDriverService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtProvider jwtProvider;

    /**
     * Registers a new user account (Customer, Driver, Staff, or Admin).
     */
    public User registerUser(UserRegisterDTO dto) {
        if (userRepository.findByEmail(dto.getEmail()).isPresent()) {
            throw new RuntimeException("Email address is already registered.");
        }

        User user = new User();
        user.setFullName(dto.getFullName());
        user.setEmail(dto.getEmail());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setRole(dto.getRole());
        user.setKycVerified(false);

        return userRepository.save(user);
    }

    /**
     * Authenticates user credentials and generates a JWT access token upon success.
     */
    public AuthResponseDTO login(LoginDTO loginDTO) {
        User user = userRepository.findByEmail(loginDTO.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found with email: " + loginDTO.getEmail()));

        if (!passwordEncoder.matches(loginDTO.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid email or password.");
        }

        String token = jwtProvider.generateToken(user.getEmail(), user.getRole().name(), user.getId());
        return new AuthResponseDTO(token, user.getEmail(), user.getRole().name(), user.getId());
    }

    /**
     * Staff/Admin physical document counter check verification.
     */
    public User verifyPhysicalKYC(Long userId, Long staffUserId) {
        User staffUser = userRepository.findById(staffUserId)
                .orElseThrow(() -> new RuntimeException("Staff user not found with ID: " + staffUserId));

        if (staffUser.getRole() != Role.ROLE_STAFF && staffUser.getRole() != Role.ROLE_ADMIN) {
            throw new RuntimeException("Access Denied: Insufficient permissions to perform KYC verification.");
        }

        User customer = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Customer account not found with ID: " + userId));

        customer.setKycVerified(true);
        return userRepository.save(customer);
    }
}